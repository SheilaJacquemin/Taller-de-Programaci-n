console.log('Inicio programa');


setTimeout(() => console.log('Primer setTimeout'), 2500);

setTimeout(() => console.log('Segund setTimeout'), 0);

setTimeout(() => console.log('Tercer setTimeout'), 0);

console.log('Fin programa');


